﻿using System;
using System.Windows.Forms;

namespace snake
{
    public partial class InputNameForm : Form
    {
        private Button okButton;
        private Button cancelButton;
        private TextBox nameTextBox;

        public string PlayerName { get; private set; }

        public InputNameForm()
        {
            InitializeComponent();
            okButton.Click += okButton_Click; // Привязка обработчика события к кнопке "ОК"
            cancelButton.Click += cancelButton_Click; // Привязка обработчика события к кнопке "Отмена"
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            // Проверка наличия введенного имени игрока
            if (!string.IsNullOrWhiteSpace(nameTextBox.Text))
            {
                PlayerName = nameTextBox.Text;
                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                MessageBox.Show("Please enter your name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void InitializeComponent()
        {
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(13, 13);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 0;
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(13, 40);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 1;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(13, 70);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 2;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            // 
            // InputNameForm
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.nameTextBox);
            this.Name = "InputNameForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}